# মোবাইল দিয়ে Naogaon Ride APK বানানোর নির্দেশনা

আপনার Android ফোন থেকেই GitHub Actions ব্যবহার করে দুটি APK বানানো যাবে। কম্পিউটার লাগবে না।

## ধাপ ১: GitHub অ্যাকাউন্ট
1. Chrome-এ https://github.com খুলুন।
2. বিনামূল্যে অ্যাকাউন্ট তৈরি/লগইন করুন।
3. `+` > `New repository` চাপুন।
4. Repository name দিন `naogaon-ride-mvp`।
5. Public বা Private বেছে `Create repository` চাপুন।

## ধাপ ২: ZIP-এর ফাইল GitHub-এ দিন
1. এই ZIP ফাইলটি ফোনে Extract করুন।
2. GitHub repository-তে `Add file` > `Upload files` নির্বাচন করুন।
3. ZIP Extract করা ফোল্ডারের ভেতরের সব ফাইল ও ফোল্ডার আপলোড করুন। `.github` ফোল্ডারটিও অবশ্যই থাকতে হবে।
4. নিচে `Commit changes` চাপুন।

## ধাপ ৩: APK তৈরি চালু করুন
1. Repository-র `Actions` ট্যাব খুলুন।
2. `Build Naogaon Ride APKs` workflow নির্বাচন করুন।
3. `Run workflow` চাপুন (অথবা ফাইল আপলোডের পর নিজে থেকেই শুরু হবে)।
4. দুইটি job শেষ হওয়া পর্যন্ত অপেক্ষা করুন। সাধারণত কয়েক মিনিট লাগতে পারে।

## ধাপ ৪: APK ডাউনলোড
1. সফল workflow run খুলুন।
2. নিচে `Artifacts` অংশে দুটি ফাইল পাবেন:
   - `passenger_app-apk`
   - `driver_app-apk`
3. প্রতিটি ZIP artifact ডাউনলোড করে Extract করুন। ভেতরে `app-release.apk` থাকবে।
4. ফোনে APK খুলে Install করুন। Android চাইলে Chrome/Files-এর জন্য “Install unknown apps” অনুমতি দিতে হতে পারে। শুধু নিজের তৈরি APK ইনস্টল করবেন।

## গুরুত্বপূর্ণ
- এটি UI/demo MVP। বুকিং এখনো বাস্তব চালক খোঁজে না; GPS, OTP, live tracking, backend, payments এবং admin panel এখনো সংযুক্ত নয়।
- APK-তে production signing, privacy policy, নিরাপত্তা পরীক্ষা ও BRTA/আইনগত অনুমোদন ছাড়া জনসাধারণের জন্য সেবা চালু করবেন না।
- GitHub Actions-এ workflow না দেখালে `.github/workflows/build-apks.yml` ফাইলটি ঠিক ওই পথেই আপলোড হয়েছে কি না দেখুন।
