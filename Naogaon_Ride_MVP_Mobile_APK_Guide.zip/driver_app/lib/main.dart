import 'package:flutter/material.dart';

void main() => runApp(const NaogaonRideDriver());

const green = Color(0xFF16834A);
const ink = Color(0xFF17231C);

class NaogaonRideDriver extends StatelessWidget {
  const NaogaonRideDriver({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Naogaon Ride Driver', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: green),
      scaffoldBackgroundColor: const Color(0xFFF5F8F5)),
    home: const DriverHome(),
  );
}

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});
  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  bool online = false;
  bool accepted = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Row(children: [
          CircleAvatar(backgroundColor: green, child: Icon(Icons.two_wheeler, color: Colors.white)),
          SizedBox(width: 10),
          Text('Naogaon Ride Driver', style: TextStyle(fontWeight: FontWeight.w800, color: ink, fontSize: 18)),
        ]),
      ),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: online ? green : const Color(0xFF52615A), borderRadius: BorderRadius.circular(22)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(online ? 'আপনি এখন অনলাইন' : 'আপনি এখন অফলাইন',
              style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(online ? 'নতুন রাইডের অনুরোধের জন্য প্রস্তুত থাকুন' : 'রাইড পেতে অনলাইন করুন',
              style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: ink),
              onPressed: () => setState(() { online = !online; accepted = false; }),
              child: Text(online ? 'অফলাইন করুন' : 'অনলাইন হোন'),
            )),
          ]),
        ),
        const SizedBox(height: 18),
        const Text('আজকের আয়', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Row(children: [
          _stat('৳ ০', 'মোট আয়', Icons.account_balance_wallet_outlined),
          const SizedBox(width: 10),
          _stat('০', 'সম্পন্ন রাইড', Icons.route_outlined),
        ]),
        const SizedBox(height: 22),
        const Text('রাইড অনুরোধ', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        if (!online)
          _notice(Icons.power_settings_new, 'রাইড পেতে অনলাইন হোন')
        else if (accepted)
          _notice(Icons.check_circle_outline, 'ডেমো রাইড গ্রহণ করা হয়েছে। বাস্তব যাত্রী ও রাইড সার্ভারের সঙ্গে সংযোগ এখনো যুক্ত হয়নি।')
        else
          Card(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('নতুন রাইড • ডেমো', style: TextStyle(fontWeight: FontWeight.bold)),
                Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(color: const Color(0xFFE7F5EC), borderRadius: BorderRadius.circular(20)),
                  child: const Text('৳ ৮০', style: TextStyle(color: green, fontWeight: FontWeight.bold))),
              ]),
              const Divider(height: 24),
              const _Place(icon: Icons.my_location, title: 'Pickup', detail: 'নওগাঁ সদর'),
              const SizedBox(height: 12),
              const _Place(icon: Icons.location_on, title: 'গন্তব্য', detail: 'মুক্তির মোড়'),
              const SizedBox(height: 14),
              const Text('আনুমানিক দূরত্ব: ৫ কিমি  •  নগদ পেমেন্ট', style: TextStyle(color: Colors.black54)),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: FilledButton(
                style: FilledButton.styleFrom(backgroundColor: green, foregroundColor: Colors.white),
                onPressed: () => setState(() => accepted = true),
                child: const Text('রাইড গ্রহণ করুন'),
              )),
            ])),
        const SizedBox(height: 20),
        const Row(children: [
          Icon(Icons.shield_outlined, color: green), SizedBox(width: 8),
          Expanded(child: Text('যাত্রীর নিরাপত্তা, ট্রাফিক আইন ও হেলমেট ব্যবহারে সচেতন থাকুন।')),
        ]),
      ]),
      bottomNavigationBar: NavigationBar(selectedIndex: 0, destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'হোম'),
        NavigationDestination(icon: Icon(Icons.history), label: 'রাইড হিস্ট্রি'),
        NavigationDestination(icon: Icon(Icons.person_outline), label: 'প্রোফাইল'),
      ]),
    );
  }

  Widget _stat(String value, String label, IconData icon) => Expanded(child: Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: green), const SizedBox(height: 10),
      Text(value, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
      Text(label, style: const TextStyle(color: Colors.black54)),
    ]),
  ));

  Widget _notice(IconData icon, String message) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: Row(children: [Icon(icon, color: green), const SizedBox(width: 12), Expanded(child: Text(message))]),
  );
}

class _Place extends StatelessWidget {
  final IconData icon; final String title; final String detail;
  const _Place({required this.icon, required this.title, required this.detail});
  @override
  Widget build(BuildContext context) => Row(children: [
    Icon(icon, color: green), const SizedBox(width: 10),
    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(color: Colors.black54, fontSize: 12)),
      Text(detail, style: const TextStyle(fontWeight: FontWeight.w600)),
    ]),
  ]);
}
