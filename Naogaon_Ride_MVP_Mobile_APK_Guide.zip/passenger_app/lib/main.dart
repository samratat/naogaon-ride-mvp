import 'package:flutter/material.dart';

void main() => runApp(const NaogaonRidePassenger());

const green = Color(0xFF16834A);
const ink = Color(0xFF17231C);

class NaogaonRidePassenger extends StatelessWidget {
  const NaogaonRidePassenger({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Naogaon Ride',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        scaffoldBackgroundColor: const Color(0xFFF5F8F5),
        appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: ink),
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: const Color(0xFFF4F7F4),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
      ),
      home: const PassengerHome(),
    );
  }
}

class PassengerHome extends StatefulWidget {
  const PassengerHome({super.key});
  @override
  State<PassengerHome> createState() => _PassengerHomeState();
}

class _PassengerHomeState extends State<PassengerHome> {
  final pickup = TextEditingController(text: 'নওগাঁ সদর');
  final destination = TextEditingController();
  bool searching = false;

  @override
  void dispose() {
    pickup.dispose();
    destination.dispose();
    super.dispose();
  }

  void bookRide() {
    if (destination.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('গন্তব্য লিখুন')),
      );
      return;
    }
    setState(() => searching = true);
    showModalBottomSheet(
      context: context, isScrollControlled: true, showDragHandle: true,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(22, 12, 22, 28),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('রাইডের অনুরোধ তৈরি হয়েছে', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('এটি ডেমো বুকিং। চালক খোঁজা ও লাইভ বুকিং চালু করতে সার্ভার সংযোগ প্রয়োজন।'),
          const SizedBox(height: 16),
          _routeRow(Icons.my_location, 'যাত্রা শুরু', pickup.text),
          _routeRow(Icons.location_on, 'গন্তব্য', destination.text),
          const SizedBox(height: 16),
          SizedBox(width: double.infinity, child: FilledButton(
            onPressed: () { Navigator.pop(ctx); setState(() => searching = false); },
            child: const Text('ঠিক আছে'),
          )),
        ]),
      ),
    ).whenComplete(() => setState(() => searching = false));
  }

  Widget _routeRow(IconData icon, String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Row(children: [Icon(icon, color: green), const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: Colors.black54, fontSize: 12)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
      ])),
    ]),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          CircleAvatar(backgroundColor: green, child: Icon(Icons.two_wheeler, color: Colors.white)),
          SizedBox(width: 10),
          Text('Naogaon Ride', style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
        actions: [IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('প্রোফাইল সুবিধা পরবর্তী সংস্করণে যুক্ত হবে')),
        ), icon: const Icon(Icons.account_circle_outlined))],
      ),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [green, Color(0xFF35A96B)]),
            borderRadius: BorderRadius.circular(24),
          ),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('নওগাঁ শহরে যাতায়াত\nএখন আরও সহজ!', style: TextStyle(color: Colors.white, fontSize: 24, height: 1.25, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('আপনার গন্তব্যে যেতে বাইক রাইড বুক করুন', style: TextStyle(color: Colors.white70)),
            SizedBox(height: 18),
            Icon(Icons.motorcycle, color: Colors.white, size: 64),
          ]),
        ),
        const SizedBox(height: 20),
        const Text('কোথায় যেতে চান?', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: ink)),
        const SizedBox(height: 12),
        Card(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
            TextField(controller: pickup, decoration: const InputDecoration(prefixIcon: Icon(Icons.my_location, color: green), labelText: 'আপনার Pickup স্থান')),
            const SizedBox(height: 12),
            TextField(controller: destination, decoration: const InputDecoration(prefixIcon: Icon(Icons.location_on, color: Colors.redAccent), labelText: 'গন্তব্য লিখুন')),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, height: 52, child: FilledButton.icon(
              onPressed: searching ? null : bookRide,
              icon: const Icon(Icons.search), label: Text(searching ? 'অনুরোধ তৈরি হচ্ছে...' : 'বাইক খুঁজুন'),
              style: FilledButton.styleFrom(backgroundColor: green, foregroundColor: Colors.white),
            )),
          ])),
        ),
        const SizedBox(height: 18),
        const Text('আপনার নিরাপত্তা আমাদের অগ্রাধিকার', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Row(children: [
          Icon(Icons.verified_user_outlined, color: green), SizedBox(width: 8),
          Expanded(child: Text('যাচাইকৃত চালক, রাইডের তথ্য ও সহায়তা সুবিধা যুক্ত করা হবে।')),
        ]),
        const SizedBox(height: 18),
        const Center(child: Text('প্রথম সংস্করণ • নওগাঁ', style: TextStyle(color: Colors.black45))),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'হোম'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'রাইড'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'প্রোফাইল'),
        ],
        onDestinationSelected: (i) {
          if (i != 0) ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('এই সুবিধাটি পরবর্তী সংস্করণে আসছে')),
          );
        },
      ),
    );
  }
}
