# Naogaon Ride MVP

Two separate Flutter Android apps:
- `passenger_app`: passenger booking UI
- `driver_app`: driver availability, incoming ride and earnings UI

## Requirements
- Flutter SDK (stable)
- Android Studio / Android SDK

## Run
From each app folder:
```bash
flutter pub get
flutter run
```

This is the first UI prototype. Booking, GPS, OTP, payments and live driver matching are mock/demo flows and are not connected to a production backend yet.

## Next production steps
1. Create backend API and PostgreSQL database.
2. Add phone OTP authentication.
3. Add verified driver onboarding and admin approval.
4. Integrate maps/location with secured API keys.
5. Implement ride matching, fare calculation and trip state machine.
6. Add SOS, trip sharing, support and audit logs.
7. Complete BRTA/legal and operational checks before public launch.
